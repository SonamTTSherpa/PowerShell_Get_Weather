﻿# Lines 2 to 4 creates the actual cmdlet
Function Get-Weather
{
    [CmdletBinding()]
              
#Lines 7 to 28 create the Parameters used in the cmdlet
    Param(
         [Parameter( 
            Mandatory = $True, 
            HelpMessage = "Enter Location Name 'City,Sate'",
            Position = 0, 
            ParameterSetName = 'Location', 
            ValueFromPipeline = $True)] 
            [string[]]$Location, 
         [Parameter( 
             Position = 1, 
             Mandatory = $False,
             HelpMessage = "Must be between 1-7", 
             ParameterSetName = 'Location')] 
             [string]$Days=7, 
         [Parameter( 
            Position = 2, 
            Mandatory = $False,
            ValueFromPipeline = $true,
            HelpMessage = "Must be C or F", 
            ParameterSetName = 'Location')] 
            [string]$Unit='F'                                                                
        ) 
  IF($Location -ne $null) {
    
#Line 31 to 36 uses a mapquest Api key to convert $Location to a Latitude & Longitude 
         $MapKey = "OaKFTRzhwJ6rdYR9VCt0w4l6RiMBLd6G" 
         $mapquest = "http://www.mapquestapi.com/geocoding/v1/address?key=$Mapkey&location=$Location"
         $Geo = Invoke-WebRequest -Uri $mapquest -UseBasicParsing | Convertfrom-json 
         $Left = $Geo.results.locations.latlng.lat
         $right = $Geo.results.locations.latlng.lng

#Line 39 to 41 uses a DarkSky Api key and the Latitude & Longitude from the previous lines to poll the weather
     $key = "a125c4574248d86b0fda8855312e7d36"
     $DarkSky = "https://api.darksky.net/forecast/$key/$left,$right"
     $weather = Invoke-webrequest -Uri $DarkSky -UseBasicParsing |ConvertFrom-Json
    

#Line 48 to 49  Uses the "-Days" Parameter value to sort get the weather based on the number of days  

  For ($i = 0; $i -lt $Days; $i++)
    {
     $HiTemp = $Weather.daily.data[$i].temperaturehigh
     $LoTemp = $Weather.daily.data[$i].temperaturelow
     $MaxTemp = IF ($unit -eq 'C'){[math]::Round((($Hitemp-32)*5)/9,2)} elseif ($unit -eq 'F') {"$Hitemp"}
     $MinTemp = IF ($unit -eq 'C'){[math]::Round((($Lotemp-32)*5)/9,2)} elseif ($unit -eq 'F') {"$Lotemp"}

     New-Object psobject -Property ([Ordered]@{
        
       "Day"                  = (get-date (Get-Date).AddDays($i) -format "ddd MMM d,yyy") 
       Summary                = $Weather.daily.data[$i].summary  
       "Temp(Max)"            = $MaxTemp
       "Temp(Min)"            = $MinTemp          
       Humidity               = $Weather.daily.data[$i].humidity
       "Precip Probability"   = $Weather.daily.data[$i].precipprobability  
      }
     )
    } 
   }
   return
  } 