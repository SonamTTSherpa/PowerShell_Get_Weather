﻿$Location = "Chicago,IL"
$unit = 'C'
$Days = "3"

     


#Line ' to ' assigns defaults for "-NumberofDays" & "-Unit" Parameters

$PSDefaultParameterValues =
         @{
         "Get-Weather:Days"="7"
         "Get-Weather:Unit"="F"
          }


#Line ' to ' use my mapquest Api key to convert $Location to a Latitude & Longitude 
         $MapKey = "OaKFTRzhwJ6rdYR9VCt0w4l6RiMBLd6G" 
         $mapquest = "http://www.mapquestapi.com/geocoding/v1/address?key=$Mapkey&location=$Location"
         $Geo = Invoke-WebRequest -Uri $mapquest -UseBasicParsing | Convertfrom-json 
         $Left = $Geo.results.locations.latlng.lat
         $right = $Geo.results.locations.latlng.lng


#Line ' to ' use my DarkSky Api key and the Lat Lng from the previous lines to poll the weather
     $Today = Get-Date -DisplayHint Date
     $key = "a125c4574248d86b0fda8855312e7d36"

#  if($Unit = ''){ $DarkSky = "https://api.darksky.net/forecast/$key/$left,$right"}
#    elseif($Unit = 'SI'){$DarkSky = "https://api.darksky.net/forecast/$key/$left,$right`b?units=si"}

    $DarkSky = "https://api.darksky.net/forecast/$key/$left,$right"

    $weather = Invoke-webrequest -Uri $DarkSky -UseBasicParsing |ConvertFrom-Json
    
#   $weather.daily.data[$numberofdays] | Format-Table -Property summary,temperaturehigh,temperaturelow,humidity,precipprobability

   $Today = (get-date (Get-Date).AddDays([Math]::Abs($i - 1) ) -format "ddd MMM d,yyy") 
   #$Today = (get-date (Get-Date).AddDays() -format "ddd MMM d,yyy")


#Line ' to ' Uses "-Days" Parameter
for ($i = 0; $i -lt $Days; $i++)
    {

     $HiTemp = $Weather.daily.data[$i].temperaturehigh
     $LoTemp = $Weather.daily.data[$i].temperaturelow
     $MaxTemp = IF ($unit -eq 'C'){[math]::Round((($Hitemp-32)*5)/9,2)} elseif ($unit -eq 'F') {"$Hitemp"}
     $MinTemp = IF ($unit -eq 'C'){[math]::Round((($Lotemp-32)*5)/9,2)} elseif ($unit -eq 'F') {"$Lotemp"}
    New-Object psobject -Property ([Ordered]@{
        
       "Day"                  = (get-date (Get-Date).AddDays($i) -format "ddd MMM d,yyy") 
       Summary                = $Weather.daily.data[$i].summary  
       "Temp(Max)"            = $MaxTemp
       "Temp(Min)"            = $MinTemp          
       Humidity               = $Weather.daily.data[$i].humidity
       "Precip Probability"   = $Weather.daily.data[$i].precipprobability  
      }
     )
    }
    
    